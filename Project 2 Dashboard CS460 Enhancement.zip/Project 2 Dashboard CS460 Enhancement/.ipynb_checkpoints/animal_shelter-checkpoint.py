from pymongo import MongoClient

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self, host='localhost', port=27017, db='AAC', col='animals'):
        """Initialize the connection to the MongoDB database."""
        self.client = MongoClient(host=host, port=port)
        self.database = self.client[db]
        self.collection = self.database[col]

    def create(self, data):
        """Insert a document into the collection."""
        if isinstance(data, dict):
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except Exception as e:
                print(f"Create error: {e}")
                return False
        else:
            raise ValueError("Data must be a dictionary.")

    def read(self, query):
        """Query documents from the collection."""
        try:
            results = self.collection.find(query)
            return [doc for doc in results]
        except Exception as e:
            print(f"Read error: {e}")
            return []
